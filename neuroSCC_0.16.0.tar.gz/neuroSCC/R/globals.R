# Declare global variables to avoid R CMD check NOTE for unquoted column names
utils::globalVariables(c("x", "y", "z", "pet"))
