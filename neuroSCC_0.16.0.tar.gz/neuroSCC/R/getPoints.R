#' Extract significant SCC points from an SCC comparison object
#'
#' @description
#' This function identifies and extracts coordinates where significant differences
#' fall outside the simultaneous confidence corridors (SCCs).
#' It processes the results from \code{ImageSCC::scc.image()}, returning the extracted coordinates
#' where the differences are statistically significant.
#'
#' The interpretation of the results depends on how the SCC was computed.
#' If SCC was computed as \code{scc.image(Ya = Y_AD, Yb = Y_CN, ...)}, meaning the
#' \strong{Control group (CN) is the second argument}, the function extracts:
#' \itemize{
#'   \item \strong{positivePoints}: Regions where \strong{Control - Pathological} is significantly above SCC.
#'     These represent \emph{areas where the Pathological group (AD) is hypoactive compared to the Control group}.
#'   \item \strong{negativePoints}: Regions where \strong{Control - Pathological} is significantly below SCC.
#'     These represent \emph{areas where the Pathological group (AD) is hyperactive compared to the Control group}.
#' }
#'
#' \strong{Make sure to check the order of Ya and Yb in the SCC computation} before interpreting the results.
#'
#' @param sccResult A list containing SCC computation results from \code{\link[ImageSCC]{scc.image}}.
#'        The list should include at least:
#' \itemize{
#'   \item \code{Z.band}: Matrix specifying grid positions.
#'   \item \code{ind.inside.cover}: Indices of grid points inside the confidence band.
#'   \item \code{scc}: 3D array containing computed SCC values.
#' }
#'
#' @return A named list:
#' \itemize{
#'   \item \code{positivePoints}: Data frame with coordinates where the \strong{first group (Ya) had significantly lower activity than the second (Yb)}.
#'   \item \code{negativePoints}: Data frame with coordinates where the \strong{first group (Ya) had significantly higher activity than the second (Yb)}.
#' }
#'
#' @examples
#' # Load precomputed SCC example
#' data("SCCcomp", package = "neuroSCC")
#'
#' # Extract significant SCC points
#' significantPoints <- getPoints(SCCcomp)
#'
#' # Show first extracted points (interpretation depends on SCC computation, see description)
#' head(significantPoints$positivePoints)  # Regions where Pathological is hypoactive vs. Control
#' head(significantPoints$negativePoints)  # Regions where Pathological is hyperactive vs. Control
#'
#' @seealso
#' \code{\link[ImageSCC]{scc.image}} for SCC computation.
#'
#' @export
getPoints <- function(sccResult) {
  # 1. Validate Input
  # ---------------------------
  if (!is.list(sccResult)) {
    stop("'sccResult' must be a list containing SCC comparison results.")
  }

  required_elements <- c("Z.band", "ind.inside.cover", "scc")
  missing_elements <- setdiff(required_elements, names(sccResult))
  if (length(missing_elements) > 0) {
    stop("Missing required elements in SCC object: ", paste(missing_elements, collapse = ", "))
  }

  # Extract required components
  Z.band <- matrix(sccResult$Z.band, ncol = 2)  # Grid positions
  insideCover <- sccResult$ind.inside.cover     # Indices inside the SCC region
  sccValues <- sccResult$scc                    # SCC values (3D array)

  # 2. Ensure SCC Data is Valid
  # ---------------------------
  if (is.null(sccValues) || all(is.na(sccValues))) {
    warning("SCC values are empty or contain only NA values. Returning empty results.")
    return(list(positivePoints = data.frame(x = numeric(), y = numeric()),
                negativePoints = data.frame(x = numeric(), y = numeric())))
  }

  # Get unique grid positions
  z1 <- unique(Z.band[, 1])
  z2 <- unique(Z.band[, 2])
  n1 <- length(z1)
  n2 <- length(z2)

  # 3. Create SCC Matrices
  # ---------------------------
  # Initialize SCC matrices
  scc <- matrix(NA, n1 * n2, 2)

  # Ensure proper alignment when assigning SCC values
  if (length(insideCover) != nrow(sccValues)) {
    stop("Mismatch: 'ind.inside.cover' length does not match SCC matrix size.")
  }

  scc[insideCover, ] <- sccValues[, , 2]  # Assign SCC confidence band values

  # Define SCC thresholds
  sccLower <- matrix(scc[, 1], nrow = n2, ncol = n1)  # Lower bound (negative SCC threshold)
  sccUpper <- matrix(scc[, 2], nrow = n2, ncol = n1)  # Upper bound (positive SCC threshold)

  # Keep only values that fall outside the SCC region:

  # If the lower bound is negative, it means the difference is too high (Control > AD),
  # so we keep only positive values.
  sccLower[sccLower < 0] <- NA  # Retain only significant positive deviations (Control > AD)

  # If the upper bound is positive, it means the difference is too low (AD > Control),
  #so we keep only negative values.
  sccUpper[sccUpper > 0] <- NA  # Retain only significant negative deviations (AD > Control)

  # 4. Identify Significant SCC Points
  # ---------------------------
  posPoints <- which(sccLower > 0, arr.ind = TRUE)  # First group stronger
  negPoints <- which(sccUpper < 0, arr.ind = TRUE)  # Second group stronger

  # 5. Convert Indexes to Coordinates
  # ---------------------------
  positiveCoords <- if (nrow(posPoints) > 0) {
    data.frame(x = z1[posPoints[, 2]], y = z2[posPoints[, 1]])
  } else {
    data.frame(x = numeric(), y = numeric())
  }

  negativeCoords <- if (nrow(negPoints) > 0) {
    data.frame(x = z1[negPoints[, 2]], y = z2[negPoints[, 1]])
  } else {
    data.frame(x = numeric(), y = numeric())
  }

  # Return structured results
  return(list(positivePoints = positiveCoords, negativePoints = negativeCoords))
}
